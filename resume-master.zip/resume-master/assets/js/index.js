window.onload = function(){
	console.log("感谢您的浏览，期待能够加入贵公司！我的 GitHub：https://github.com/hackhu2019");
}
